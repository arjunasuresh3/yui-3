{
    // ARIA live region notifications.
    item_selected  : "{item} selected.",
    items_available: "Suggestions are available. Use up and down arrows to select."
}
