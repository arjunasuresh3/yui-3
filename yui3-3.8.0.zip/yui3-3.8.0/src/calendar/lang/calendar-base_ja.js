{
    weekdays : ["\u65E5\u66DC\u65E5", "\u6708\u66DC\u65E5", "\u706B\u66DC\u65E5", "\u6C34\u66DC\u65E5", "\u6728\u66DC\u65E5", "\u91D1\u66DC\u65E5", "\u571F\u66DC\u65E5"],
    short_weekdays : ["\u65E5\u66DC", "\u6708\u66DC", "\u706B\u66DC", "\u6C34\u66DC", "\u6728\u66DC", "\u91D1\u66DC", "\u571F\u66DC"],
    very_short_weekdays : ["\u65E5", "\u6708", "\u706B", "\u6C34", "\u6728", "\u91D1", "\u571F"],
    first_weekday : 0,
    weekends : [0,6]
}
