{
    weekdays : ["Søndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "Lørdag"],
    very_short_weekdays : ["Sø", "Ma", "Ti", "On", "To", "Fr", "Lø"],
    first_weekday : 1,
    weekends : [0,6]
}
