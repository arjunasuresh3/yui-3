{
    weekdays : ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"],
    short_weekdays : ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"],
    very_short_weekdays : ["Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa"],
    first_weekday : 1,
    weekends : [0,6]
}
