Anim Change History
===================

3.8.0
-----

* No changes.

3.7.3
-----

* No changes.

3.7.2
-----

* No changes.

3.7.1
-----

* No changes.

3.7.0
-----

* Added `anim-shape` submodule which allows for animation of all shape
  attributes in the `graphics` module. [Ticket #2532612]

3.6.0
-----
  * Allow for pass through to object properties for arbitrary animation.

3.5.1
-----

  * No changes.

3.5.0
-----
  * No changes.


3.4.1
-----
  * no change


3.4.0
-----
  * no change


3.3.0
-----

  * Bug fix: A glitch occurred when an reversing a previously reversed
    animation. [Ticket 2528581]


3.2.0
-----

  * Bug fix: Better cleanup on destroy. [Ticket 2528820]
  * Bug fix: Was not resuming properly from pause. [Ticket 2528938]


3.1.1
-----
  * no change


3.1.0
-----
  * Now firing the resume event.
  * Added a boolean arg for stop() to force it to skip to the last frame.


3.0.0
-----
  * Initial release.
