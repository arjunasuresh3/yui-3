Attribute
=========

The Attribute utility allows you to add attributes to any class 
through an augmentable Attribute interface. The interface adds 
get and set methods to your class for attribute access, in 
addition to supporting change events allowing you to listen 
for changes in attribute values.